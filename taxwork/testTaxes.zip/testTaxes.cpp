#include "ResidentialBuilding.h"
#include "FemaleCitizen.h"
#include "MaleCitizen.h"
#include "TaxType.h"
#include "Income.h"
#include "Government.h"
#include "TaxSystem.h"
#include <iostream>
#include <thread>
#include <chrono>
#include <memory>  // For smart pointers

int main() {
    // Create Government instance
    auto government = std::make_shared<Government>("City Government");

    // Create TaxSystem instance and add the government
    TaxSystem taxSystem;
    taxSystem.addGovernment(government.get());

    // Create TaxType instance for income tax
    auto incomeTax = std::make_shared<Income>(0.1); // Example rate: 10%
    taxSystem.addTaxRate(incomeTax.get());

    // Create ResidentialBuilding
    auto resBuilding = std::make_shared<ResidentialBuilding>("Sunset Apartments", 5000.0f, 10, 100, 80.0f,
                                                             2.0f, 1.5f, 50, 7.5f);

    // Add the building to the tax system
    taxSystem.addIncomeTaxBuilding(resBuilding.get());

    // Create Citizens
    auto citizen1 = std::make_shared<FemaleCitizen>("Alice", 30, "Single", "Engineer");
    auto citizen2 = std::make_shared<MaleCitizen>("Bob", 45, "Single", "Teacher");

    // Set income for citizens
    citizen1->setIncome(50000.0);  // Example income
    citizen2->setIncome(60000.0);  // Example income

    // Set bank balance for citizens
    citizen1->updateBankBalance(50000.0); // Initial bank balance
    citizen2->updateBankBalance(60000.0); // Initial bank balance

    // Add residents to the building
    resBuilding->addResidents(citizen1.get());
    resBuilding->addResidents(citizen2.get());

    // Simulate tax collection through the tax system
    std::cout << "First tax collection:\n";
    taxSystem.collectTaxes(resBuilding.get(), 'I');  // 'I' for Income Tax

    std::cout << "\nAttempting immediate second tax collection (should be on cooldown):\n";
    taxSystem.collectTaxes(resBuilding.get(), 'I');  // 'I' for Income Tax

    // Wait for the cooldown period to expire
    std::cout << "\nWaiting for cooldown to expire...\n";
    std::this_thread::sleep_for(std::chrono::seconds(10));

    std::cout << "\nAttempting tax collection after cooldown:\n";
    taxSystem.collectTaxes(resBuilding.get(), 'I');  // 'I' for Income Tax

    return 0;
}
